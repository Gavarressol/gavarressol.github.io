# Projecte de Programació (GEINF/GEB - UdG)

## Primavera 2024

> Jocs de proves

- [testsProf](testsProf): jocs de proves proporcionats pels professors
- [tests](tests): jocs de proves realitzats per nosaltres
