[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/jxkKLcuv)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=14320491)
# Projecte de Programació (GEINF/GEB - UdG)

## Primavera 2024

> Trobareu l'enunciat al [Moodle](https://moodle.udg.edu/course/view.php?id=36070)

**Carpetes**

- [doc](doc): documentació en format PDF (veure enunciat)
- [doc/html](doc/html): documentació en format html generada amb [Doxygen](http://www.doxygen.nl/)
- [lib](lib): biblioteques auxiliars (fitxers JAR)
- [out/artifacts](out/artifacts): fitxer JAR de l'aplicació
- [src](src): codi font (fitxers .java)
- [test](test): joc de proves
