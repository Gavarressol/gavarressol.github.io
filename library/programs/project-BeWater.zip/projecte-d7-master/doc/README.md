# Projecte de Programació (GEINF/GEB - UdG)

## Primavera 2024

> Documentació en format PDF (veure enunciat)
