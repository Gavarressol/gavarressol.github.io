var searchData=
[
  ['node_0',['node',['../class_xarxa.html#ac2fb01e420a9efe5d013da6c3d25e0b4',1,'Xarxa']]],
  ['node1_1',['node1',['../class_canonada.html#add5baf3adf35132bc328f7f45b0bf3a7',1,'Canonada']]],
  ['node2_2',['node2',['../class_canonada.html#a50c5156883999228c31c34eff8a84db9',1,'Canonada']]],
  ['nodeaixeta_3',['NodeAixeta',['../class_node_aixeta.html#a37b5249a1b3c2da13da5c2aa3f93ce23',1,'NodeAixeta']]],
  ['nodesordenats_4',['nodesOrdenats',['../class_gestor_xarxes.html#ad9edd2ee02d5fd240f09950e41093bab',1,'GestorXarxes']]]
];
