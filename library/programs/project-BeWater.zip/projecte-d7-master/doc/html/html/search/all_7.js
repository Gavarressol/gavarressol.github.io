var searchData=
[
  ['feina_0',['Repartició de feina',['../md__c_1_2_users_2aleix_2projects_2proj_pro_2proj_2ij_2projecte-d7_2src_2_r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['fluxmaxim_1',['fluxMaxim',['../class_gestor_xarxes.html#a06132634b519e01136ad0f55d2664e93',1,'GestorXarxes']]]
];
