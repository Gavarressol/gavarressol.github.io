var searchData=
[
  ['fluxmaxim_0',['fluxMaxim',['../class_gestor_xarxes.html#a06132634b519e01136ad0f55d2664e93',1,'GestorXarxes']]]
];
