var indexSectionsWithContent =
{
  0: "2_abcdefgilmnoprstux",
  1: "bcgnostx",
  2: "bcgnorstx",
  3: "abcdefgilmnorstx",
  4: "_acr",
  5: "bdgpu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables",
  5: "Pàgines"
};

