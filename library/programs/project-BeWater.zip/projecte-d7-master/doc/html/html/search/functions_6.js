var searchData=
[
  ['getalatitud_0',['getAlatitud',['../class_coordenades.html#a2ecfaca30086840644117f789ac3784e',1,'Coordenades']]],
  ['getalongitud_1',['getAlongitud',['../class_coordenades.html#abc2d9142b7f8935df0b131d1f6bad20d',1,'Coordenades']]]
];
