var searchData=
[
  ['xarxa_0',['Xarxa',['../class_xarxa.html',1,'']]]
];
