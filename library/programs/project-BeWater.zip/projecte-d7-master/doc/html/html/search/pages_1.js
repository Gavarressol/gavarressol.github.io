var searchData=
[
  ['de_20programació_20geinf_20geb_20udg_0',['Projecte de Programació (GEINF/GEB - UdG)',['../md__c_1_2_users_2aleix_2projects_2proj_pro_2proj_2ij_2projecte-d7_2src_2_r_e_a_d_m_e.html',1,'']]]
];
