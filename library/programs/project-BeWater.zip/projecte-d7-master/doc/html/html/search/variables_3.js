var searchData=
[
  ['radi_5fterra_0',['RADI_TERRA',['../class_coordenades.html#a821d71f1251823952be4d195e509eb2f',1,'Coordenades']]]
];
