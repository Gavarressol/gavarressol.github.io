var searchData=
[
  ['abonar_0',['abonar',['../class_xarxa.html#a475ba8fae1253e89038a40facf6e3a37',1,'Xarxa']]],
  ['afegir_1',['afegir',['../class_xarxa.html#ad1d4b91e851fdfd8d1621543b7d5c01e',1,'Xarxa.afegir(Origen nodeOrigen)'],['../class_xarxa.html#a8b1f2ee135a2579a0e84e4011bb5a46e',1,'Xarxa.afegir(Terminal nodeTerminal)'],['../class_xarxa.html#a10d95b7d2eb4f067da93a2d565cc3c3c',1,'Xarxa.afegir(Connexio nodeConnexio)']]],
  ['aixetaoberta_2',['aixetaOberta',['../class_node_aixeta.html#abc42af0213d387ddd4c03edec5770c62',1,'NodeAixeta']]],
  ['aixetestancar_3',['aixetesTancar',['../class_gestor_xarxes.html#a7d51af69de370700b78f51254bd900e2',1,'GestorXarxes']]]
];
