var searchData=
[
  ['tancaraixeta_0',['tancaraixeta',['../class_node_aixeta.html#af38fc51825e8416dde43a916136f66c2',1,'NodeAixeta.tancarAixeta()'],['../class_xarxa.html#a659f7ccc5cae7e406a7ee0b1a07f693b',1,'Xarxa.tancarAixeta()']]],
  ['tecicles_1',['teCicles',['../class_gestor_xarxes.html#a51fa1439ecaabee3627f77eed9122ad3',1,'GestorXarxes']]],
  ['terminal_2',['terminal',['../class_terminal.html',1,'Terminal'],['../class_terminal.html#a3f7cc7d7a840bb6c4ff45d04d237b8d5',1,'Terminal.Terminal()']]],
  ['terminal_2ejava_3',['Terminal.java',['../_terminal_8java.html',1,'']]],
  ['trobarcanonada_4',['trobarCanonada',['../class_simulador_mode_text.html#a10bc7c5e97dd276c1461be0ffbbd08d3',1,'SimuladorModeText']]]
];
