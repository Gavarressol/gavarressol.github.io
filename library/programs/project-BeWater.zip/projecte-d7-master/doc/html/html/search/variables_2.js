var searchData=
[
  ['comptadorlinies_0',['comptadorLinies',['../class_simulador_mode_text.html#a0a517da28416152589c7e291b9e24807',1,'SimuladorModeText']]]
];
