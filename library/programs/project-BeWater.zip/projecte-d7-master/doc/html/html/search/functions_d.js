var searchData=
[
  ['simular_0',['simular',['../class_simulador_mode_text.html#acf46c7460ef06bf77ae48ab3217c40f1',1,'SimuladorModeText']]],
  ['sortides_1',['sortides',['../class_xarxa.html#a02680efa33036bc4143db53170bd1e05',1,'Xarxa']]]
];
