var searchData=
[
  ['simuladormodetext_0',['SimuladorModeText',['../class_simulador_mode_text.html',1,'']]]
];
