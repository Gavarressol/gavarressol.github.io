var searchData=
[
  ['xarxa_0',['Xarxa',['../class_xarxa.html#a7781e55d04b354f6fec02fa99d52e3a0',1,'Xarxa']]]
];
