var searchData=
[
  ['obriraixeta_0',['obriraixeta',['../class_node_aixeta.html#ab513db34e133fcbd0f63dc1abd95e0bb',1,'NodeAixeta.obrirAixeta()'],['../class_xarxa.html#aa13943fb4c8f5517ef5a411e8d13babb',1,'Xarxa.obrirAixeta()']]],
  ['origen_1',['origen',['../class_origen.html',1,'Origen'],['../class_origen.html#a64676e38e2b7d9f92d1a119bf3e5dccd',1,'Origen.Origen()']]],
  ['origen_2ejava_2',['Origen.java',['../_origen_8java.html',1,'']]]
];
