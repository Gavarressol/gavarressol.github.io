var searchData=
[
  ['_5faixetaoberta_0',['_aixetaOberta',['../class_node_aixeta.html#a9ef03aebaa0027f10068958e4b701e49',1,'NodeAixeta']]],
  ['_5fcabal_1',['_cabal',['../class_origen.html#a7fa2a25a2b0667f31f8f4b9915c24cdb',1,'Origen']]],
  ['_5fcapacitat_2',['_capacitat',['../class_canonada.html#a1763e9d01954c0fd699d1729e7d090d3',1,'Canonada']]],
  ['_5fclients_3',['_clients',['../class_xarxa.html#aa9c28785142e69bec0d3215cb727377c',1,'Xarxa']]],
  ['_5fcoordenades_4',['_coordenades',['../class_node_aixeta.html#a503be600dd7c45f9efff1dba3879c622',1,'NodeAixeta']]],
  ['_5fdemandaactual_5',['_demandaActual',['../class_terminal.html#ad5d945179155f6f8ccaf80dbba9682bd',1,'Terminal']]],
  ['_5fdemandapunta_6',['_demandaPunta',['../class_terminal.html#a5559a1e608db479e80671369e092f1cc',1,'Terminal']]],
  ['_5fid_7',['_id',['../class_node_aixeta.html#ac98d9f2f9b0986f0cc8bdb4bf3477ae8',1,'NodeAixeta']]],
  ['_5fmodifaixetes_8',['_modifAixetes',['../class_xarxa.html#a2dcd513ccd4136905ed0f71ccf485217',1,'Xarxa']]],
  ['_5fnode1_9',['_node1',['../class_canonada.html#a0c0327207752cb44eab92662b560866a',1,'Canonada']]],
  ['_5fnode2_10',['_node2',['../class_canonada.html#a021c94a759ab95fbe3ef81099b6a63bb',1,'Canonada']]],
  ['_5fxarxa_11',['_xarxa',['../class_simulador_mode_text.html#a50207e85bd58ebfd4873e7600eb9727e',1,'SimuladorModeText._xarxa'],['../class_xarxa.html#a6d18a426a5d1cf334342e9af586d4f50',1,'Xarxa._xarxa']]]
];
