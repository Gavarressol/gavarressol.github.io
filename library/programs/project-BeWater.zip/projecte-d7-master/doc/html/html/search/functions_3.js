var searchData=
[
  ['demanda_0',['demanda',['../class_xarxa.html#adcd8f7fb8f883a1d958b709bd4254ec3',1,'Xarxa']]],
  ['demandaactual_1',['demandaActual',['../class_terminal.html#ab4d99557e296d22096df28b71dcf0250',1,'Terminal']]],
  ['demandapunta_2',['demandaPunta',['../class_terminal.html#ad6574d187929c6244fb8c1dcfe506b6e',1,'Terminal']]],
  ['dfsconnex_3',['dfsConnex',['../class_gestor_xarxes.html#a8dc25aca4b2f9592137eb651a6266b0d',1,'GestorXarxes']]],
  ['dibuixar_4',['dibuixar',['../class_xarxa.html#a644452390beb298a9a47f5e074c9a353',1,'Xarxa']]],
  ['distancia_5',['distancia',['../class_coordenades.html#af0623aa8643efc99b90f77622392d6a5',1,'Coordenades']]]
];
