var searchData=
[
  ['radi_5fterra_0',['RADI_TERRA',['../class_coordenades.html#a821d71f1251823952be4d195e509eb2f',1,'Coordenades']]],
  ['readme_2emd_1',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['recorregutcicle_2',['recorregutCicle',['../class_gestor_xarxes.html#ab78893a7b542bbce4397af1ebd18562e',1,'GestorXarxes']]],
  ['recular_3',['recular',['../class_xarxa.html#a1162fd976e1518879fb145d8bb9fb338',1,'Xarxa']]],
  ['repartició_20de_20feina_4',['Repartició de feina',['../md__c_1_2_users_2aleix_2projects_2proj_pro_2proj_2ij_2projecte-d7_2src_2_r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['retornabonat_5',['retornAbonat',['../class_xarxa.html#a1af7908f824833333731140da0240726',1,'Xarxa']]]
];
