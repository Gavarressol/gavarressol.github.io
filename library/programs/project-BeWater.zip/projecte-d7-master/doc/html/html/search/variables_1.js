var searchData=
[
  ['alatitud_0',['alatitud',['../class_coordenades.html#a7302c266da4b24a4385e88f7af1eaa15',1,'Coordenades']]],
  ['alongitud_1',['alongitud',['../class_coordenades.html#aee851c1c80207c17e7004fa94da63ad3',1,'Coordenades']]]
];
