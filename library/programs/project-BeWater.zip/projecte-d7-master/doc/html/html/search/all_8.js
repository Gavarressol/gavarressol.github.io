var searchData=
[
  ['geb_20udg_0',['Projecte de Programació (GEINF/GEB - UdG)',['../md__c_1_2_users_2aleix_2projects_2proj_pro_2proj_2ij_2projecte-d7_2src_2_r_e_a_d_m_e.html',1,'']]],
  ['geinf_20geb_20udg_1',['Projecte de Programació (GEINF/GEB - UdG)',['../md__c_1_2_users_2aleix_2projects_2proj_pro_2proj_2ij_2projecte-d7_2src_2_r_e_a_d_m_e.html',1,'']]],
  ['gestorxarxes_2',['GestorXarxes',['../class_gestor_xarxes.html',1,'']]],
  ['gestorxarxes_2ejava_3',['GestorXarxes.java',['../_gestor_xarxes_8java.html',1,'']]],
  ['getalatitud_4',['getAlatitud',['../class_coordenades.html#a2ecfaca30086840644117f789ac3784e',1,'Coordenades']]],
  ['getalongitud_5',['getAlongitud',['../class_coordenades.html#abc2d9142b7f8935df0b131d1f6bad20d',1,'Coordenades']]]
];
