var searchData=
[
  ['origen_0',['Origen',['../class_origen.html',1,'']]]
];
