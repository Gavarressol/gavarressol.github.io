var searchData=
[
  ['simuladormodetext_2ejava_0',['SimuladorModeText.java',['../_simulador_mode_text_8java.html',1,'']]]
];
