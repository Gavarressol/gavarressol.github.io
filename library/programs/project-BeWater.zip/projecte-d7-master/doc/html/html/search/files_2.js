var searchData=
[
  ['gestorxarxes_2ejava_0',['GestorXarxes.java',['../_gestor_xarxes_8java.html',1,'']]]
];
