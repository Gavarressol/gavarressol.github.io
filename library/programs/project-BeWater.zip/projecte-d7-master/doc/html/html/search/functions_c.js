var searchData=
[
  ['recorregutcicle_0',['recorregutCicle',['../class_gestor_xarxes.html#ab78893a7b542bbce4397af1ebd18562e',1,'GestorXarxes']]],
  ['recular_1',['recular',['../class_xarxa.html#a1162fd976e1518879fb145d8bb9fb338',1,'Xarxa']]],
  ['retornabonat_2',['retornAbonat',['../class_xarxa.html#a1af7908f824833333731140da0240726',1,'Xarxa']]]
];
