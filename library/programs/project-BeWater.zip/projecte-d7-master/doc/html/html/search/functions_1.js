var searchData=
[
  ['buscarcabalmaxim_0',['buscarCabalMaxim',['../class_gestor_xarxes.html#ac679c9ad0c436c0342f761d3f167bff7',1,'GestorXarxes']]],
  ['buscarorigen_1',['buscarOrigen',['../class_simulador_mode_text.html#af0c3d4719a4f75625520c2bd1f3bf613',1,'SimuladorModeText']]]
];
