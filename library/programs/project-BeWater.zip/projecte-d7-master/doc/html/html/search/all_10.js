var searchData=
[
  ['simuladormodetext_0',['SimuladorModeText',['../class_simulador_mode_text.html',1,'']]],
  ['simuladormodetext_2ejava_1',['SimuladorModeText.java',['../_simulador_mode_text_8java.html',1,'']]],
  ['simular_2',['simular',['../class_simulador_mode_text.html#acf46c7460ef06bf77ae48ab3217c40f1',1,'SimuladorModeText']]],
  ['sortides_3',['sortides',['../class_xarxa.html#a02680efa33036bc4143db53170bd1e05',1,'Xarxa']]]
];
