var searchData=
[
  ['de_20feina_0',['Repartició de feina',['../md__c_1_2_users_2aleix_2projects_2proj_pro_2proj_2ij_2projecte-d7_2src_2_r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['de_20programació_20geinf_20geb_20udg_1',['Projecte de Programació (GEINF/GEB - UdG)',['../md__c_1_2_users_2aleix_2projects_2proj_pro_2proj_2ij_2projecte-d7_2src_2_r_e_a_d_m_e.html',1,'']]],
  ['demanda_2',['demanda',['../class_xarxa.html#adcd8f7fb8f883a1d958b709bd4254ec3',1,'Xarxa']]],
  ['demandaactual_3',['demandaActual',['../class_terminal.html#ab4d99557e296d22096df28b71dcf0250',1,'Terminal']]],
  ['demandapunta_4',['demandaPunta',['../class_terminal.html#ad6574d187929c6244fb8c1dcfe506b6e',1,'Terminal']]],
  ['dfsconnex_5',['dfsConnex',['../class_gestor_xarxes.html#a8dc25aca4b2f9592137eb651a6266b0d',1,'GestorXarxes']]],
  ['dibuixar_6',['dibuixar',['../class_xarxa.html#a644452390beb298a9a47f5e074c9a353',1,'Xarxa']]],
  ['distancia_7',['distancia',['../class_coordenades.html#af0623aa8643efc99b90f77622392d6a5',1,'Coordenades']]]
];
