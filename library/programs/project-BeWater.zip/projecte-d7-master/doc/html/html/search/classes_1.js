var searchData=
[
  ['canonada_0',['Canonada',['../class_canonada.html',1,'']]],
  ['connexio_1',['Connexio',['../class_connexio.html',1,'']]],
  ['coordenades_2',['Coordenades',['../class_coordenades.html',1,'']]]
];
