var searchData=
[
  ['xarxa_0',['xarxa',['../class_xarxa.html',1,'Xarxa'],['../class_xarxa.html#a7781e55d04b354f6fec02fa99d52e3a0',1,'Xarxa.Xarxa()']]],
  ['xarxa_2ejava_1',['Xarxa.java',['../_xarxa_8java.html',1,'']]]
];
