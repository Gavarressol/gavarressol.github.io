var searchData=
[
  ['eliminarfills_0',['eliminarFills',['../class_gestor_xarxes.html#ab71282c05543f6f16daa313ea20c44fb',1,'GestorXarxes']]],
  ['enllaçarsprites_1',['enllaçarSprites',['../class_xarxa.html#a913586697079c9e6844de4c8c8bd0254',1,'Xarxa']]],
  ['entrades_2',['entrades',['../class_xarxa.html#afe582745498e42a253c40f59f9b8c6ce',1,'Xarxa']]],
  ['esarbre_3',['esArbre',['../class_gestor_xarxes.html#aef6c5c914fde2624b680c0cc1775a403',1,'GestorXarxes']]],
  ['esconnex_4',['esConnex',['../class_gestor_xarxes.html#a3ef76bc7aacab2d890734a3d13de7d92',1,'GestorXarxes']]],
  ['establircabal_5',['establircabal',['../class_origen.html#ae368d55fb365f672fdda2f9b384b88f2',1,'Origen.establirCabal()'],['../class_xarxa.html#af97bed7e986eb497a15edb3a30e31825',1,'Xarxa.establirCabal(Origen nodeOrigen, float cabal)']]],
  ['establirdemanda_6',['establirDemanda',['../class_xarxa.html#a3ec71c5575218566f9f71416407191be',1,'Xarxa']]],
  ['establirdemandaactual_7',['establirDemandaActual',['../class_terminal.html#a7ed45a824a9fd4bc12cc23cde658e726',1,'Terminal']]],
  ['excescabal_8',['excesCabal',['../class_gestor_xarxes.html#ae878c285c51f0a76a2abb8de5fb75cfb',1,'GestorXarxes']]],
  ['existeixclient_9',['existeixClient',['../class_xarxa.html#a739e0f400db902581c7c969bdab200c2',1,'Xarxa']]]
];
