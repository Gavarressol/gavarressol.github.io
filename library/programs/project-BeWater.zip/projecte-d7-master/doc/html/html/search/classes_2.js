var searchData=
[
  ['gestorxarxes_0',['GestorXarxes',['../class_gestor_xarxes.html',1,'']]]
];
