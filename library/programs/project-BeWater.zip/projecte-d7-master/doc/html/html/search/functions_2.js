var searchData=
[
  ['cabal_0',['cabal',['../class_origen.html#a4519bdb1ab8f7f01d880ac6a4aca5014',1,'Origen.cabal()'],['../class_xarxa.html#adaa9748254ce3c69078fb310c26240ad',1,'Xarxa.cabal(NodeAixeta node)']]],
  ['cabalabonat_1',['cabalAbonat',['../class_xarxa.html#af96338a999076f2e1f553344fe876eb7',1,'Xarxa']]],
  ['cabalminim_2',['cabalMinim',['../class_gestor_xarxes.html#ad6c1adeced5adf43b6ac8be94abf68a0',1,'GestorXarxes']]],
  ['calculcabalcanonada_3',['calculCabalCanonada',['../class_xarxa.html#a2e7fcf2e1eb1a7ea77f2d40b8ac51495',1,'Xarxa']]],
  ['calculdemandacanonada_4',['calculDemandaCanonada',['../class_xarxa.html#a8e4fd4b92d7ed7b4dfa2721003bc1178',1,'Xarxa']]],
  ['cambiaropcio_5',['CambiarOpcio',['../class_simulador_mode_text.html#ad0bc9e5e1e2a78d8a894576c1f3f42bb',1,'SimuladorModeText']]],
  ['canonada_6',['Canonada',['../class_canonada.html#a69c7dc7cf5472597253baff435eef944',1,'Canonada']]],
  ['canviarestat_7',['canviarEstat',['../class_node_aixeta.html#a11bbc51b163aadde36d56242f9e42fc0',1,'NodeAixeta']]],
  ['capacitat_8',['capacitat',['../class_canonada.html#a0615873ebdfdf3b6f8e42c7267942890',1,'Canonada']]],
  ['connectarambcanonada_9',['connectarAmbCanonada',['../class_xarxa.html#ab85333f399f42cbafcbf3b12ba1c8ce1',1,'Xarxa']]],
  ['connexio_10',['Connexio',['../class_connexio.html#a6eadac95a6df6516b09129f44407d814',1,'Connexio']]],
  ['coordenades_11',['coordenades',['../class_node_aixeta.html#a804fd738681b48f8bd30fa0054c826e5',1,'NodeAixeta.coordenades()'],['../class_coordenades.html#a449a3361caf6236cd50aa47ea0d894bf',1,'Coordenades.Coordenades(int grausLatitud, int minutsLatitud, float segonsLatitud, char direccioLatitud, int grausLongitud, int minutsLongitud, float segonsLongitud, char direccioLongitud)'],['../class_coordenades.html#a3a9ac695fb355d2efa4d80cc4f009be3',1,'Coordenades.Coordenades(float latitud, float longitud)']]],
  ['copiagraf_12',['copiaGraf',['../class_xarxa.html#ae077535225c5cb5787a5c3af7c5d93d2',1,'Xarxa']]],
  ['crearmaxflow_13',['crearMaxFlow',['../class_gestor_xarxes.html#aa37ac2ac3dfd37f5738ec6a7f6b1a7ee',1,'GestorXarxes']]],
  ['crearpipe_14',['crearPipe',['../class_gestor_xarxes.html#a177558746736df4eb42f9aff43e1c6ea',1,'GestorXarxes']]],
  ['crearsubgraf_15',['crearSubGraf',['../class_xarxa.html#ab7f455b274d613eef981f2189562901e',1,'Xarxa']]]
];
